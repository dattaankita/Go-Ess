package main

import "fmt"

func main() {
	fmt.Println("Welcome to go")
}
