package main

import "fmt"

func main() {
	//declarations
	var a int
	var isTrue bool
	var myName string
//assignments
	a = 10
	isTrue = true
	myName = "Kiran Paturi"
	fmt.Println(a)
	fmt.Println(isTrue)
	fmt.Println(myName)

}
