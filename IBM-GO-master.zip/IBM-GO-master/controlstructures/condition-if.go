package main

import "fmt"

func main() {
	/* comments
	dkkkekeke
	*/
	x := 100
	if x < 100 {
		fmt.Println("I am less than hudered")
	} else if x == 100 {
		fmt.Println("I am hundred")
	}
}
