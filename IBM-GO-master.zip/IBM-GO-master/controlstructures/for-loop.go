package main

import "fmt"

func main() {
	/* comments
	dkkkekeke
	*/

	for x := 0; x < 10; x++ {
		fmt.Println(x)
		if x > 5 {
			break
		}
	}

}
