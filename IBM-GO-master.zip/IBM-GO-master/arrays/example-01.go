package main

import "fmt"

func main() {
	/* Array Declaration*/
	var employees [3]string
	employees[0] = "Kiran"
	employees[1] = "Akita"
	employees[2] = "Rupesh"
	fmt.Println(employees[2])

}
